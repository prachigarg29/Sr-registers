﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;


public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        registerLogin objcls = new registerLogin();
        objcls._femail = txtemail.Text.Trim();
        objcls._fpswd = txtpswd.Text.Trim();
        DataSet ds = objcls.Stulogin();
        if (ds.Tables[0].Rows.Count > 0)
        {
            Response.Write("<script>alert('login successfully...')</script>");
            Session.Add("Fid", Convert.ToInt64(ds.Tables[0].Rows[0]["facultyid"].ToString()));
            Session.Add("Fname", ds.Tables[0].Rows[0]["facultyName"].ToString());
            txtemail.Text = string.Empty;
            txtpswd.Text = string.Empty;
            Response.Redirect("DashBoard.aspx");
        }
        //string con = "Data Source=DELLINSPIRON\\PMSSQLSERVER;Initial Catalog=SRrecord;Integrated Security=True";
        //SqlConnection sqlcon = new SqlConnection(clscon._conn);
        //string cmd = @"select * from [SRrecord].[dbo].[faculty_details]  where [facultyEmail]='" + txtemail.Text.Trim() + "' and [Fpswd]='" + txtpswd.Text.Trim() + "'";
        //SqlDataAdapter sqlad = new SqlDataAdapter(cmd, sqlcon);
        //DataSet ds = new DataSet();
        //sqlad.Fill(ds);
        //if (ds.Tables[0].Rows.Count > 0)
        //{
        //    Response.Write("<script>alert('login successfully...')</script>");

        //    txtemail.Text = string.Empty;
        //    txtpswd.Text = string.Empty;
        //    Response.Redirect("AddRecord.aspx");
        //}
    }
}