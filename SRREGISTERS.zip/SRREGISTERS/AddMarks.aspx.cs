﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
using System.Web.Services;
public partial class AddMarks : System.Web.UI.Page
{
    long id = 0;
    long markid = 0;
    string srollno;
    protected void Page_Load(object sender, EventArgs e)
    {
        pnl1st.Visible = false;
        pnlfinlstatus.Visible = false;
        txtmarks.Text = string.Empty;
        txtOutOfMarks.Text = string.Empty;
        if (Request.QueryString.HasKeys())
            {
                if (Request.QueryString["v"].ToString() == "AM")
                {
                    id = Convert.ToInt64(Request.QueryString["id"].ToString());
                    fetchrollNO();
                    fetchdata();
                }

            }
    }
    public void insertUPDATE1st()
    {
        SqlConnection sqlcon = new SqlConnection(clscon._conn);
        string cmd = @"select * FROM  [SRregister].[dbo].[tbl_marks] where [stuId]=" + id;
        SqlDataAdapter sqlad = new SqlDataAdapter(cmd, sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            {
                //SqlConnection sqlcon = new SqlConnection(clscon._conn);
                string cmd1 = @"update [SRregister].[dbo].[tbl_marks] set [Marks_1st_sem]='" + txtmarks.Text.Trim() + "',[Marks_outOF_1sem]='" + txtOutOfMarks.Text.Trim() + "' [stuId]=" + id;
                SqlCommand sqlcmd1 = new SqlCommand(cmd1, sqlcon);
                sqlcon.Open();
                if (sqlcmd1.ExecuteNonQuery() > 0)
                {
                    Response.Redirect("ShowRecord.aspx");
                }
            }
        }
        else
        {
           // SqlConnection sqlcon = new SqlConnection(clscon._conn);
            string cmd2 = @"insert into [SRregister].[dbo].[tbl_marks] ([stu_RollNo],[Marks_1st_sem],[Marks_outOF_1sem],[stuId]) 
                    values ('" + txtRollNo.Text.Trim() + "','" + txtmarks.Text.Trim() + "','" + txtOutOfMarks.Text.Trim() + "','" + id + "') ";
            SqlCommand sqlcmd = new SqlCommand(cmd2, sqlcon);
            sqlcon.Open();
            if (sqlcmd.ExecuteNonQuery() > 0)
            {
                Response.Redirect("ShowRecord.aspx");
            }
        }
    }

    protected void btnSAVE_Click(object sender, EventArgs e)
    {
        markid = Convert.ToInt64(Session["mid"]);
        if (Request.QueryString.HasKeys())
        {
            if (Request.QueryString["v"].ToString() == "AM")
            {
                if (dropdownMarks.SelectedItem.Value == "1")
                {
                    insertUPDATE1st();
                }
                else if (dropdownMarks.SelectedItem.Value == "2")
                {
                    SqlConnection sqlcon = new SqlConnection(clscon._conn);
                    string cmdfetchmarks = @"select [Marks_1st_sem] from [SRregister].[dbo].[tbl_marks]  where [stuId]=" + id;
                    SqlDataAdapter sqlad = new SqlDataAdapter(cmdfetchmarks, sqlcon);
                    DataSet ds = new DataSet();
                    sqlad.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        string marks = ds.Tables[0].Rows[0]["Marks_1st_sem"].ToString();
                        if (marks != "")
                        {
                            string cmd = @"update [SRregister].[dbo].[tbl_marks] set [Marks_2nd_sem]='" + txtmarks.Text.Trim() + "',[Marks_outOF_2sem]='" + txtOutOfMarks.Text.Trim() + "' where [stuId]=" + id;
                            SqlCommand sqlcmd = new SqlCommand(cmd, sqlcon);
                            sqlcon.Open();
                            if (sqlcmd.ExecuteNonQuery() > 0)
                            {
                                Response.Redirect("ShowRecord.aspx");
                            }
                        }
                    }
                    else
                    {

                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Firstly insert 1st sem marks ..');", true);

                        //Response.Redirect("AddMarks.aspx?v=AM&id=" + id);
                    }
                }
                else if (dropdownMarks.SelectedItem.Value == "3")
                {
                    SqlConnection sqlcon = new SqlConnection(clscon._conn);
                    string cmdfetchmarks = @"select [Marks_2nd_sem],[Marks_1st_sem] from [SRregister].[dbo].[tbl_marks]  where [stuId]=" + id;
                    SqlDataAdapter sqlad = new SqlDataAdapter(cmdfetchmarks, sqlcon);
                    DataSet ds = new DataSet();
                    sqlad.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        string marks2 = ds.Tables[0].Rows[0]["Marks_2nd_sem"].ToString();
                        string marks1 = ds.Tables[0].Rows[0]["Marks_1st_sem"].ToString();
                        if (marks1 != ""|| marks2!="")
                        {

                            string cmd = @"update [SRregister].[dbo].[tbl_marks] set Marks_3rd_sem='" + txtmarks.Text.Trim() + "',Marks_outOF_3sem='" + txtOutOfMarks.Text.Trim() + "' where [stuId]=" + id;
                            SqlCommand sqlcmd = new SqlCommand(cmd, sqlcon);
                            sqlcon.Open();
                            if (sqlcmd.ExecuteNonQuery() > 0)
                            {
                                Response.Redirect("ShowRecord.aspx");
                            }
                        }
                    }
                    else
                    {

                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Firstly insert 1st,2nd sem marks ..');", true);

                        //Response.Redirect("AddMarks.aspx?v=AM&id=" + id);
                    }
                }
                else if (dropdownMarks.SelectedItem.Value == "4")
                {
                    SqlConnection sqlcon = new SqlConnection(clscon._conn);
                    string cmdfetchmarks = @"select [Marks_3rd_sem],[Marks_2nd_sem],[Marks_1st_sem] from [SRregister].[dbo].[tbl_marks]  where [stuId]=" + id;
                    SqlDataAdapter sqlad = new SqlDataAdapter(cmdfetchmarks, sqlcon);
                    DataSet ds = new DataSet();
                    sqlad.Fill(ds);
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        string marks3 = ds.Tables[0].Rows[0]["Marks_3rd_sem"].ToString();
                        string marks2 = ds.Tables[0].Rows[0]["Marks_2nd_sem"].ToString();
                        string marks1 = ds.Tables[0].Rows[0]["Marks_1st_sem"].ToString();
                        if (marks1 != ""|| marks2 != ""|| marks3 != "")
                        {

                            string cmd = @"update [SRregister].[dbo].[tbl_marks] set [Marks_4th_sem]='" + txtmarks.Text.Trim() + "',[Marks_outOF_4sem]='" + txtOutOfMarks.Text.Trim() + "',PG_status='" + txtstatus.Value + "' where [stuId]=" + id;
                            SqlCommand sqlcmd = new SqlCommand(cmd, sqlcon);
                            sqlcon.Open();
                            if (sqlcmd.ExecuteNonQuery() > 0)
                            {
                                Response.Redirect("ShowRecord.aspx");
                            }
                        }
                    }
                    else
                    {

                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Firstly insert 1st,2nd,3rd sem marks ..');", true);

                        //Response.Redirect("AddMarks.aspx?v=AM&id=" + id);
                    }
                }

            }
        }
    }
    public void fetchrollNO()
    {
        SqlConnection sqlcon = new SqlConnection(clscon._conn);
        string cmd = @"select * FROM  [SRregister].[dbo].[srRecords] where [STudentID]=" + id;
        SqlDataAdapter sqlad = new SqlDataAdapter(cmd, sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {
            txtRollNo.Text = ds.Tables[0].Rows[0]["RollNo"].ToString();
        }

    }
    public void fetchdata()
    {
        SqlConnection sqlcon = new SqlConnection(clscon._conn);
        string cmd = @"select * FROM  [SRregister].[dbo].[tbl_marks] where [stuId]=" + id;
        SqlDataAdapter sqlad = new SqlDataAdapter(cmd, sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            markid = Convert.ToInt64(ds.Tables[0].Rows[0]["marksID"].ToString());
            Session.Add("mid", markid);

        }
    }


    protected void dropdownMarks_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (dropdownMarks.SelectedItem.Value == "1")
        {
            pnl1st.Visible = true;
            pnlfinlstatus.Visible = false;
            SqlConnection sqlcon = new SqlConnection(clscon._conn);
            string cmd = @"select * FROM  [SRregister].[dbo].[tbl_marks] where [stuId]=" + id;
            SqlDataAdapter sqlad = new SqlDataAdapter(cmd, sqlcon);
            DataSet ds = new DataSet();
            sqlad.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                txtmarks.Text = ds.Tables[0].Rows[0]["Marks_1st_sem"].ToString();
                txtOutOfMarks.Text = ds.Tables[0].Rows[0]["Marks_outOF_1sem"].ToString();

            }
        }
        else if (dropdownMarks.SelectedItem.Value == "2")
        {
            pnl1st.Visible = true;
            pnlfinlstatus.Visible = false;
            SqlConnection sqlcon1 = new SqlConnection(clscon._conn);
            string cmd1 = @"select * FROM  [SRregister].[dbo].[tbl_marks] where [stuId]=" + id;
            SqlDataAdapter sqlad1 = new SqlDataAdapter(cmd1, sqlcon1);
            DataSet ds1 = new DataSet();
            sqlad1.Fill(ds1);
            if (ds1.Tables[0].Rows.Count > 0)
            {
                txtmarks.Text = ds1.Tables[0].Rows[0]["Marks_2nd_sem"].ToString();
                txtOutOfMarks.Text = ds1.Tables[0].Rows[0]["Marks_outOF_2sem"].ToString();

            }
        }
        else if (dropdownMarks.SelectedItem.Value == "3")
        {
            pnl1st.Visible = true;
            pnlfinlstatus.Visible = false;
            SqlConnection sqlcon1 = new SqlConnection(clscon._conn);
            string cmd1 = @"select * FROM  [SRregister].[dbo].[tbl_marks] where [stuId]=" + id;
            SqlDataAdapter sqlad1 = new SqlDataAdapter(cmd1, sqlcon1);
            DataSet ds1 = new DataSet();
            sqlad1.Fill(ds1);
            if (ds1.Tables[0].Rows.Count > 0)
            {
                txtmarks.Text = ds1.Tables[0].Rows[0]["Marks_3rd_sem"].ToString();
                txtOutOfMarks.Text = ds1.Tables[0].Rows[0]["Marks_outOF_3sem"].ToString();

            }
        }
        else if (dropdownMarks.SelectedItem.Value == "4")
        {
            pnl1st.Visible = true;
            pnlfinlstatus.Visible = true;
            SqlConnection sqlcon1 = new SqlConnection(clscon._conn);
            string cmd1 = @"select * FROM  [SRregister].[dbo].[tbl_marks] where [stuId]=" + id;
            SqlDataAdapter sqlad1 = new SqlDataAdapter(cmd1, sqlcon1);
            DataSet ds1 = new DataSet();
            sqlad1.Fill(ds1);
            if (ds1.Tables[0].Rows.Count > 0)
            {
                txtmarks.Text = ds1.Tables[0].Rows[0]["Marks_4th_sem"].ToString();
                txtOutOfMarks.Text = ds1.Tables[0].Rows[0]["Marks_outOF_4sem"].ToString();
            }
        }
    }


}