﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using Microsoft.Office.Interop.Excel;
using System.Data.OleDb;
using System.Data.Common;
using System.Globalization;
using System.Diagnostics;
using System.Web.Script.Serialization;

public partial class _Default : System.Web.UI.Page
{
    string id;
    protected void Page_Load(object sender, EventArgs e)
    {
        pnladd.Visible = false;
        pnlBulkUpload.Visible = false;
        if (Request.QueryString.HasKeys())
        {
            if (Request.QueryString["v"].ToString() == "AR")
            {
                pnladd.Visible = true;
                pnlBulkUpload.Visible = false;
            }
            else if (Request.QueryString["v"].ToString() == "BR")
            {
                pnladd.Visible = false;
                pnlBulkUpload.Visible = true;
            }
        }

    }


    protected void btnSAVE_Click(object sender, EventArgs e)
    {

        clsAddRecord objcls = new clsAddRecord();
        objcls._rollNO = txtRollNo.Text;
        objcls._name = txtname.Text;
        objcls._fatherName = txtFatherName.Text;
        objcls._contactNO = txtMobileNo.Text;
        objcls._whatsappNO = txtwtspNO.Text;
        objcls._adress = txtAddress.Text;
        objcls._gender = txtgender.Value;
        objcls._category = txtCategory.Text;
        objcls._email = txtEmail.Text;
        objcls._adharID = txtAdharNO.Text;
        objcls._PANid = txtPANno.Text;
        objcls._DOB = txtDOB.Text;
        objcls._ABCid = txtABCid.Text;
        objcls._UGcourse = txtUGcourse.Text;
        objcls._PGcourse = txtPGcourse.Text;
        objcls._admission = txtDateAdd.Text;
        objcls._10Year = txt10thYear.Text;
        objcls._10Per = txt10thPercentage.Text;
        objcls._10RollNO = txt10thRoll.Text;
        objcls._10Board = txt10thBoard.Text;
        objcls._10schoolName = txt10schoolName.Text;
        objcls._12Year = txt12thYear.Text;
        objcls._12Per = txt12thPercentage.Text;
        objcls._12RollNO = txt12thRoll.Text;
        objcls._12Board = txt12thBoard.Text;
        objcls._12schoolName = txt12thschoolName.Text;
        objcls._graduation = txtGraduationYear.Text;
        objcls._university = txtUniversity.Text;
        objcls._sd = txtSD.Text;
        objcls._Nonsd = txtNonSD.Text;
        objcls._userid = Convert.ToInt64(Session["Fid"]);
        int res = objcls.add();
        if (res > 0)
        {
            Response.Redirect("ShowRecord.aspx");

        }

        #region
        //        SqlConnection con = new SqlConnection(clscon._conn);
        //        string cmd = @"INSERT INTO [dbo].[srRecords]([NameOfStudent],[DOB],[Course],[RegistrationNO],[Gender],[Category],[Religion],[Nationality]
        //           ,[FatherName],[Occupation],[MotherName],[ResidentialAddress],[ContactNo],[DurationOfResidenceInUP],[LastClassPassed]
        //           ,[NameOfInsitutionLastAttended],[DateOfAdmission],[MarksofXth],[MarksOfXIIth],[MarksOfUG],[MarksOf1stSemInternal],[MarksOf1stSemExternal]
        //           ,[MarksOf2ndSemInternal]
        //           ,[MarksOf2ndSemExternal]
        //           ,[MarksOf3rdSemInternal]
        //           ,[MarksOf3rdSemExternal]
        //           ,[MarksOf4thSemInternal]
        //           ,[MarksOf4thSemExternal]
        //           ,[MarksOf5thSemInternal]
        //           ,[MarksOf5thSemExternal]
        //           ,[MarksOf6thSemInternal]
        //           ,[MarksOf6thSemExternal]
        //           ,[TotalMarksObtained]
        //           ,[Division]
        //           ,[MeritPosition]
        //           ,[DateOfIssueOfCertificate]
        //           ,[SignatureOfStudent]
        //           ,[IntitalOfClerk]
        //           ,[Remarks])
        //              values ('" + txtname.Text.Trim() + "','" + txtDOB.Text + "','" + txtCourse.Value + "','" + txtRegNo.Text.Trim() + "','" + txtgender.Value + "','" + txtCategory.Text.Trim() + "','" + txtreligion.Text.Trim() + "','" + txtNationality.Text.Trim() + "','" + txtFatherName.Text.Trim() + "','" + txtOccupation.Text.Trim() + "','" + txtMotherName.Text.Trim() + "','" + txtAddress.Text.Trim() + "','" + txtMobileNo.Text.Trim() + "','" + txtDuration.Text.Trim() + "','" + txtLastCls.Text.Trim() + "','" + txtInsitution.Text.Trim() + "','" + txtDateAdd.Text.Trim() + "',@marksofxth, @marksofxiith, @marksofug, @marksof1stseminternal, @marksof1stsemexternal,@marksof2ndseminternal, @marksof2ndsemexternal, @marksof3rdseminternal, @marksof3rdsemexternal,@marksof4thseminternal, @marksof4thsemexternal, @marksof5thseminternal, @marksof5thsemexternal,@marksof6thseminternal, @marksof6thsemexternal, @totalmarksobtained, @division, @meritposition,@dateofissueofcertificate, @signatureofstudent, @intitalofclerk, @remarks)";
        //        SqlCommand sqlcmd = new SqlCommand(cmd, con);
        //        con.Open();
        //        sqlcmd.Parameters.AddWithValue("@marksofxth", float.Parse(txtXth.Text));
        //        sqlcmd.Parameters.AddWithValue("@marksofxiith", float.Parse(txtXIIth.Text));
        //        sqlcmd.Parameters.AddWithValue("@marksofug", float.Parse(txtUG.Text));
        //        sqlcmd.Parameters.AddWithValue("@marksof1stseminternal", float.Parse(txtIn1stSem.Text));
        //        sqlcmd.Parameters.AddWithValue("@marksof1stsemexternal", float.Parse(txtEx1stsem.Text));
        //        sqlcmd.Parameters.AddWithValue("@marksof2ndseminternal", float.Parse(txtIn2ndSem.Text));
        //        sqlcmd.Parameters.AddWithValue("@marksof2ndsemexternal", float.Parse(txtEx2ndsem.Text));
        //        sqlcmd.Parameters.AddWithValue("@marksof3rdseminternal", float.Parse(txtIn3rdsem.Text));
        //        sqlcmd.Parameters.AddWithValue("@marksof3rdsemexternal", float.Parse(txtEx3rdSem.Text));
        //        sqlcmd.Parameters.AddWithValue("@marksof4thseminternal", float.Parse(txtIn4thSem.Text));
        //        sqlcmd.Parameters.AddWithValue("@marksof4thsemexternal", float.Parse(txtEx4thsem.Text));
        //        sqlcmd.Parameters.AddWithValue("@marksof5thseminternal", float.Parse(txtIn5thSem.Text));
        //        sqlcmd.Parameters.AddWithValue("@marksof5thsemexternal", float.Parse(txtEx5thSem.Text));
        //        sqlcmd.Parameters.AddWithValue("@marksof6thseminternal", float.Parse(txtIn6thSem.Text));
        //        sqlcmd.Parameters.AddWithValue("@marksof6thsemexternal", float.Parse(txtEx6thSem.Text));
        //        sqlcmd.Parameters.AddWithValue("@totalmarksobtained", float.Parse(txtTotalMarks.Text));
        //        sqlcmd.Parameters.AddWithValue("@division", (txtDivision.Text.Trim()));
        //        sqlcmd.Parameters.AddWithValue("@meritposition", (txtMDiv.Text.Trim()));
        //        sqlcmd.Parameters.AddWithValue("@dateofissueofcertificate", (txtDOICerti.Text));
        //        sqlcmd.Parameters.AddWithValue("@signatureofstudent", (txtSign.Text.Trim()));
        //        sqlcmd.Parameters.AddWithValue("@intitalofclerk", (txtIntitalClerk.Text.Trim()));
        //        sqlcmd.Parameters.AddWithValue("@remarks", float.Parse(txtremark.Text));
        //        int i = sqlcmd.ExecuteNonQuery();
        //        if (i > 0)
        //        {
        //            Response.Write("<script>alert('added successfully...')</script>");
        //            Response.Redirect("showrecord.aspx");
        //        }
        #endregion
    }
    public void updateid()
    {
        id = Session["Fid"].ToString();
        SqlConnection sqlcon = new SqlConnection(clscon._conn);
        string strcmd = @"update [SRregister].[dbo].[srRecords] set [UserID]='" + id + "' ";
        SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
        sqlcon.Open();
        if (sqlcmd.ExecuteNonQuery() > 0)
        {

        }
    }
    protected void FileSubmit_Click(object sender, EventArgs e)
    {

        //  id = Session["Fid"].ToString();
        if (excelFileUp.PostedFile != null)
        {
            SqlConnection sqlCon = new SqlConnection(clscon._conn);
            
            string str = @"select * from srRecords";
            SqlDataAdapter sda = new SqlDataAdapter(str, sqlCon);
            System.Data.DataTable dt = new System.Data.DataTable();

            sda.Fill(dt);
            System.Data.DataTable fdt = new System.Data.DataTable();

            Microsoft.Office.Interop.Excel.Application oxl = new Microsoft.Office.Interop.Excel.Application();
            string strPath = "C:\\Users\\29pra\\Desktop\\" + excelFileUp.FileName;
            //System.IO.Path.GetFullPath(excelFileUp.FileName); 
            Microsoft.Office.Interop.Excel.Workbook wrb = oxl.Workbooks.Open(strPath);

            //oxl.Visible = true;
            string connectionStringexcel = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + strPath + ";Extended Properties=\"Excel 8.0;HDR=YES;\"";
            System.Data.DataTable Data = new System.Data.DataTable();

            OleDbConnection conn = new OleDbConnection(connectionStringexcel);

            conn.Open();
            OleDbCommand cmd = new OleDbCommand(@"SELECT * FROM [MCA$]", conn);
            OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
            adapter.Fill(Data);
            conn.Close();
            if (dt.Rows.Count == 0)
            {

                SqlBulkCopy bulkCopy = new SqlBulkCopy(clscon._conn);

                bulkCopy.DestinationTableName = "srRecords";
                bulkCopy.ColumnMappings.Add("rollno", "RollNo");
                bulkCopy.ColumnMappings.Add("Student_Name", "NameOfStudent");
                bulkCopy.ColumnMappings.Add("Father_Name", "FatherName");
                bulkCopy.ColumnMappings.Add("MobileNo", "ContactNo");
                bulkCopy.ColumnMappings.Add("Address", "StudAddress");
                bulkCopy.ColumnMappings.Add("Gender", "Gender");
                bulkCopy.ColumnMappings.Add("Category", "Category");
                bulkCopy.ColumnMappings.Add("E_MAIL", "EmailiD");
                bulkCopy.ColumnMappings.Add("Adhar_Card", "AdharCardNO");
                bulkCopy.ColumnMappings.Add("DOB", "DOB");
                bulkCopy.ColumnMappings.Add("Admission_Date", "AddmissonDate");
                bulkCopy.ColumnMappings.Add("10Passing_Year", "PassYearOf10");
                bulkCopy.ColumnMappings.Add("10Percentage", "PercentageOf10");
                bulkCopy.ColumnMappings.Add("10th_RollNo", "RollNoOf10");
                bulkCopy.ColumnMappings.Add("Board", "Board");
                bulkCopy.ColumnMappings.Add("school_name", "SchoolName");
                bulkCopy.ColumnMappings.Add("12_PassingYear", "PassingYearOf12");
                bulkCopy.ColumnMappings.Add("12th_Percentage", "PercentageOf12");
                bulkCopy.ColumnMappings.Add("12_RollNo", "RollNoOf12");
                bulkCopy.ColumnMappings.Add("12thBoard", "BoardOf12");
                bulkCopy.ColumnMappings.Add("School_Name", "schoolNameOf12");
                bulkCopy.ColumnMappings.Add("Graduation_YEAR", "GraduationYear");
                bulkCopy.ColumnMappings.Add("Univeristy", "University");
                bulkCopy.ColumnMappings.Add("SD", "SD");
                bulkCopy.ColumnMappings.Add("OtherNonSD", "OtherNonSD");
                bulkCopy.ColumnMappings.Add("UID", "UserID");

                bulkCopy.WriteToServer(Data);
                updateid();
                KillSpecificExcelFileProcess(strPath);
                Response.Redirect("ShowRecord.aspx");
                
            }

            else if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < Data.Rows.Count; i++)
                {
                    string strQu = @"select * from [srRecords] where [RollNo] = '" + Convert.ToString(Data.Rows[i]["RollNo"].ToString()) + "'";
                    // SqlDataAdapter sqlsda = new SqlDataAdapter(strQu, sqlCon);
                    object objAcc = SqlHelper.ExecuteScalar(sqlCon, CommandType.Text, strQu);
                    // sqlsda.Fill(rdt);
                    if (Convert.ToInt64(objAcc) > 0)
                    {
                        //bulkCopy.WriteToServer(Data);
                        // Response.Write("Data already exixt...");
                    }
                    else
                    {
                        string strIn = @"insert into  [SRregister].[dbo].[srRecords] 
                                           ([RollNo]
                                          ,[NameOfStudent]
                                          ,[FatherName]
                                          ,[ContactNo]
                                          ,[StudAddress]
                                          ,[Gender]
                                          ,[Category]
                                          ,[EmailiD]
                                          ,[AdharCardNO]
                                          ,[DOB]
                                          ,[AddmissonDate]
                                          ,[PassYearOf10]
                                          ,[PercentageOf10]
                                          ,[RollNoOf10]
                                          ,[Board]
                                          ,[SchoolName]
                                          ,[PassingYearOf12]
                                          ,[PercentageOf12]
                                          ,[RollNoOf12]
                                          ,[BoardOf12]
                                          ,[schoolNameOf12]
                                          ,[GraduationYear]
                                          ,[University]
                                          ,[SD]
                                          ,[OtherNonSD]) VALUES ('" + Data.Rows[i]["rollno"].ToString() + "','" + Data.Rows[i]["Student_Name"].ToString() + "','" + Data.Rows[i]["Father_Name"].ToString() + "','" + Data.Rows[i]["MobileNo"].ToString() + "','" + Data.Rows[i]["Address"].ToString() + "','" + Data.Rows[i]["Gender"].ToString() + "','" + Data.Rows[i]["Category"].ToString() + "','" + Data.Rows[i]["E_MAIL"].ToString() + "','" + Data.Rows[i]["Adhar_Card"].ToString() + "','" + Data.Rows[i]["DOB"].ToString() + "','" + Data.Rows[i]["Admission_Date"].ToString() + "','" + Data.Rows[i]["10Passing_Year"].ToString() + "','" + Data.Rows[i]["10Percentage"].ToString() + "','" + Data.Rows[i]["10th_RollNo"].ToString() + "','" + Data.Rows[i]["Board"].ToString() + "','" + Data.Rows[i]["school_name"].ToString() + "','" + Data.Rows[i]["12_PassingYear"].ToString() + "','" + Data.Rows[i]["12th_Percentage"].ToString() + "','" + Data.Rows[i]["12_RollNo"].ToString() + "','" + Data.Rows[i]["12thBoard"].ToString() + "','" + Data.Rows[i]["School_Name"].ToString() + "','" + Data.Rows[i]["Graduation_YEAR"].ToString() + "','" + Data.Rows[i]["Univeristy"].ToString() + "','" + Data.Rows[i]["SD"].ToString() + "','" + Data.Rows[i]["OtherNonSD"].ToString() + "' )";
                        SqlCommand sqlCmd = new SqlCommand(strIn, sqlCon);
                        sqlCon.Open();
                        sqlCmd.ExecuteNonQuery();
                        sqlCon.Close();
                    }
                }
            }


            wrb.Close();

            oxl.Quit();

            KillSpecificExcelFileProcess(strPath);
        }


    }
    private void KillSpecificExcelFileProcess(string excelFileName)
    {
        var processes = from p in Process.GetProcessesByName("EXCEL")
                        select p;

        foreach (var process in processes)
        {
            if (process.MainWindowTitle == "Microsoft Excel - " + excelFileName)
                process.Kill();
        }
    }
   

  
}