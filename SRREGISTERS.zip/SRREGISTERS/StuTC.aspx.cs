﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using System.Web.Services;
public partial class StuTC : System.Web.UI.Page
{
    string rNo, sts;
    protected void Page_Load(object sender, EventArgs e)
    {
        //// getid();
        //txtrollno.Text = Request.QueryString["rollNo"].ToString();
        //txtname.Text = ds.Tables[0].Rows[0]["NameOfStudent"].ToString();
        //txtgender.Text = ds.Tables[0].Rows[0]["Gender"].ToString();
        //txtfathername.Text = ds.Tables[0].Rows[0]["FatherName"].ToString();
        //txtcat.Text = ds.Tables[0].Rows[0]["Category"].ToString();
        //txtDOB.Text = ds.Tables[0].Rows[0]["DOB"].ToString();
        //txtadharNO.Text = ds.Tables[0].Rows[0]["AdharCardNO"].ToString();
        //txtPAN.Text = ds.Tables[0].Rows[0]["PAN_NO"].ToString();
        //txtPGcourse.Text = ds.Tables[0].Rows[0]["PG_courseName"].ToString();
        //txtStatus.Text = ds.Tables[0].Rows[0]["PG_status"].ToString();


    }
    //public void getid()
    //{
    //    SqlConnection sqlcon = new SqlConnection(clscon._conn);
    //    string cmd = @"SELECT
    //                    CASE
    //                        WHEN sr.[RollNo] = tm.[stu_RollNo] THEN sr.[RollNo]
    //                    ELSE NULL
    //                    END AS[RollNo],
    //                    sr.*,
    //                    tm.*
    //                FROM
    //                    [SRregister].[dbo].[srRecords]
    //                    AS sr
    //                LEFT JOIN
    //                    [SRregister].[dbo].[tbl_marks]
    //                    AS tm ON sr.[RollNo] = tm.[stu_RollNo] OR sr.[RollNo] = tm.[stu_RollNo]
    //                WHERE
    //                sr.[RollNo] = '" + txtrollno.Text.Trim() + "' ";
    //    SqlDataAdapter sqlcmd = new SqlDataAdapter(cmd, sqlcon);
    //    DataSet ds = new DataSet();
    //    sqlcmd.Fill(ds);
    //    if (ds.Tables[0].Rows.Count > 0)
    //    {
    //        long idd = Convert.ToInt64(ds.Tables[0].Rows[0]["STudentID"].ToString());
    //        Session.Add("studentid", idd);
    //        rNo = ds.Tables[0].Rows[0]["RollNo"].ToString();
    //        Session.Add("sRollNo", rNo);
    //        sts = ds.Tables[0].Rows[0]["PG_status"].ToString();
    //        Session.Add("Status", sts);
    //    }
    //}
    [WebMethod]
    public static List<string> getcompleteList(string RollNo)
    {
        List<string> getitem = new List<string>();
        SqlConnection sqlcon = new SqlConnection(clscon._conn);
        DataSet ds = new DataSet();
        System.Data.DataTable dt = new System.Data.DataTable();
        using (SqlCommand cmd = new SqlCommand())
        {
            cmd.CommandText = @"select [RollNo] from [SRregister].[dbo].[srRecords] where [RollNo] like @Text";
            cmd.Parameters.AddWithValue("@Text", "%" + RollNo + "%");
            cmd.Connection = sqlcon;
            sqlcon.Open();

            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            ad.Fill(ds);
        }
        sqlcon.Close();

        dt = ds.Tables[0];
        List<string> txtItems = new List<string>();
        String dbValues;

        foreach (DataRow row in dt.Rows)
        {
            //String From DataBase(dbValues)
            dbValues = row["RollNo"].ToString();
            //dbValues = dbValues.ToLower();
            txtItems.Add(dbValues);
        }

        return txtItems;
        //return getitem;
    }

    protected void btnGenerateTC_Click(object sender, EventArgs e)
    {
            Response.Redirect("BindReport.aspx");
        


        #region
        //if (status == "Passed")
        //{
        //    Response.Redirect("BindReport.aspx");
        //}
        //else if (status == "")
        //{
        //    Response.Write("<script>alert('Student has No status so Tc can't Generate')</script>");
        //}
        //else if (status == "Failed")
        //{
        //    Response.Write("<script>alert('Student is fail We can't generate TC')</script>");
        //}
        //else if (status == "Left")
        //{
        //    Response.Write("<script>alert('Student is Left We can't generate TC')</script>");
        //}
        #endregion
    }


    protected void verifybtn_Click(object sender, EventArgs e)
    {

        SqlConnection sqlcon = new SqlConnection(clscon._conn);
        string cmd = @"SELECT
                        COALESCE(sr.[RollNo], tm.[stu_RollNo]) AS RollNo,
                        sr.*, -- Include all columns from srRecords table
                        tm.*  -- Include all columns from tbl_marks table
                    FROM
                        [SRregister].[dbo].[srRecords] AS sr
                    LEFT JOIN
                        [SRregister].[dbo].[tbl_marks] AS tm ON sr.[RollNo] = tm.[stu_RollNo]
                    WHERE
                        sr.[RollNo] = '" + txtrollno.Text.Trim() + "'";

        SqlDataAdapter sqlcmd = new SqlDataAdapter(cmd, sqlcon);
        DataSet ds = new DataSet();
        sqlcmd.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            //Session.Add("studentid", Convert.ToInt64(ds.Tables[0].Rows[0]["STudentID"].ToString()));
            txtname.Text = ds.Tables[0].Rows[0]["NameOfStudent"].ToString();
            rNo = ds.Tables[0].Rows[0]["RollNo"].ToString();
            Session.Add("sRollNo", txtrollno.Text);

            txtgender.Text = ds.Tables[0].Rows[0]["Gender"].ToString();
            txtfathername.Text = ds.Tables[0].Rows[0]["FatherName"].ToString();
            txtcat.Text = ds.Tables[0].Rows[0]["Category"].ToString();
            txtDOB.Text = ds.Tables[0].Rows[0]["DOB"].ToString();
            txtadharNO.Text = ds.Tables[0].Rows[0]["AdharCardNO"].ToString();
            txtPAN.Text = ds.Tables[0].Rows[0]["PAN_NO"].ToString();
            txtPGcourse.Text = ds.Tables[0].Rows[0]["PG_courseName"].ToString();
            txtStatus.Text = ds.Tables[0].Rows[0]["PG_status"].ToString();
            sts = ds.Tables[0].Rows[0]["PG_status"].ToString();
            Session.Add("Status", sts);
            verifybtn.ForeColor = System.Drawing.Color.Green;
            verifybtn.Text = "Verified";

        }
    }


    protected void BtnGenerateCC_Click(object sender, EventArgs e)
    {
        Response.Redirect("BindCC.aspx");
    }
}