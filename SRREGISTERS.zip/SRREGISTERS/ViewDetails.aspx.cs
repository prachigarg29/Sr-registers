﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class ViewDetails : System.Web.UI.Page
{
    long id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString.HasKeys())
        {
            id = Convert.ToInt64(Request.QueryString["id"].ToString());
        }

        SqlConnection sqlcon = new SqlConnection(clscon._conn);

        string cmd = @"SELECT *
                        FROM [SRregister].[dbo].[srRecords] AS sr
                        FULL JOIN [SRregister].[dbo].[tbl_marks] AS tm ON  sr.RollNo = tm.[stu_RollNo]
                        WHERE sr.STudentID = " + id;
        SqlDataAdapter sqlad = new SqlDataAdapter(cmd, sqlcon);

        DataSet ds = new DataSet();
        sqlad.Fill(ds);

        if (ds.Tables[0].Rows.Count > 0)
        {
            string name = ds.Tables[0].Rows[0]["NameOfStudent"].ToString();
            Session.Add("name", name);
            string rollno = ds.Tables[0].Rows[0]["RollNo"].ToString();
            Session.Add("rollno", rollno);
            ShowRecordDT.DataSource = ds;
            ShowRecordDT.DataBind();

        }


    }

    
}