﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;
using Microsoft.Reporting.WebForms;

public partial class BindReport : System.Web.UI.Page
{
    string rollno;
    protected void Page_Load(object sender, EventArgs e)
    {
        #region
        //if (!IsPostBack)
        //{
        //    //set Processing Mode of Report as Local  
        //    ReportViewer1.ProcessingMode = ProcessingMode.Local;
        //    //set path of the Local report  
        //    ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Report.rdlc");
        //    //creating object of DataSet dsEmployee and filling the DataSet using SQLDataAdapter  
        //    DataSet dsemp = new DataSet();
        //    SqlConnection con = new SqlConnection(clscon._conn);
        //    con.Open();
        //    string rollno = Session["sRollNo"].ToString();

        //    SqlParameter[] parameters = new SqlParameter[1];
        //    parameters[0] = new SqlParameter("@id", SqlDbType.VarChar);
        //    parameters[0].Value = rollno.ToString();

        //    DataSet ds = SqlHelper.ExecuteDataset(clscon._conn, CommandType.StoredProcedure, "TCgenerated", parameters);
        //    //adapt.Fill(dsemp, "DataTable1");
        //    con.Close();

        //    //Providing DataSource for the Report  
        //    ReportDataSource rds = new ReportDataSource("DataSet1",ds.Tables[0]);
        //    ReportViewer1.LocalReport.DataSources.Clear();
        //    //Add ReportDataSource  
        //    ReportViewer1.LocalReport.DataSources.Add(rds);
        //}
        #endregion
        if (!IsPostBack)
        {
            if (Session["sRollNo"] != null)
            {
                 rollno = Session["sRollNo"].ToString();
                // Assuming clscon._conn is your connection string
                using (SqlConnection con = new SqlConnection(clscon._conn))
                {
                    using (SqlCommand cmd = new SqlCommand("TCgenerated", con))
                    {
                        updateTCdata();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@rollno", rollno);
                        using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                        {
                            DataSet ds = new DataSet();
                            da.Fill(ds);
                            //set Processing Mode of Report as Local
                            ReportViewer1.ProcessingMode =  ProcessingMode.Local;
                            //set path of the Local report
                            ReportViewer1.LocalReport.ReportPath = Server.MapPath("~/Report.rdlc");
                            //Providing DataSource for the Report
                            ReportDataSource rds = new ReportDataSource("DataSet1", ds.Tables[0]);
                            ReportViewer1.LocalReport.DataSources.Clear();
                            //Add ReportDataSource
                            ReportViewer1.LocalReport.DataSources.Add(rds);
                        }
                    }
                }
                
            }
            else
            {
                // Handle the case when Session["sRollNo"] is null
                // Redirect or display an error message
            }
        }
    }
   public void updateTCdata()
    {
        long id = Convert.ToInt64(Session["Fid"]);

        string status = Session["Status"].ToString();

        SqlConnection sqlcon = new SqlConnection(clscon._conn);
        string strUpd = @"update [SRregister].[dbo].[srRecords] set TcGenerated='" + 1 + "' , IdOfTC='" + id + "', DateOfTC=GETDATE(), TcTime=CONVERT(time, GETDATE()) where [RollNo]='" + rollno + "'";

        SqlCommand sqlcmd = new SqlCommand(strUpd, sqlcon);
        sqlcon.Open();
        if (sqlcmd.ExecuteNonQuery() > 0)
        {

        }

    }
}