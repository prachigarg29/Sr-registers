﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Summary description for WebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
[System.Web.Script.Services.ScriptService]
public class WebService : System.Web.Services.WebService
{

    public WebService()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public string[] getcompleteList(string Prefixtext, int count)
    {
        List<string> getitem = new List<string>();
        SqlConnection sqlcon = new SqlConnection(clscon._conn);
        DataSet ds = new DataSet();
        DataTable dt = new DataTable();
        using (SqlCommand cmd = new SqlCommand())
        {
            cmd.CommandText = @"select [RollNo] from [SRregister].[dbo].[srRecords] where [RollNo] like @Text";
            cmd.Parameters.AddWithValue("@Text", "%" + Prefixtext + "%");
            cmd.Connection = sqlcon;
            sqlcon.Open();

            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            ad.Fill(ds);

            //using (SqlDataReader r = cmd.ExecuteReader())
            //{
            //    while (r.Read())
            //    {
            //        getitem.Add(r["RollNo"].ToString());
            //    }

            //}

        }
        sqlcon.Close();

        dt = ds.Tables[0];
        List<string> txtItems = new List<string>();
        String dbValues;

        foreach (DataRow row in dt.Rows)
        {
            //String From DataBase(dbValues)
            dbValues = row["RollNo"].ToString();
            //dbValues = dbValues.ToLower();
            txtItems.Add(dbValues);
        }

        return txtItems.ToArray();
        //return getitem;
    }

}
