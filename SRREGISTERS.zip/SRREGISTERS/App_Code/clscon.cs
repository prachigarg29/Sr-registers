﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
/// <summary>
/// Summary description for clscon
/// </summary>
public static class clscon
{
    static string con = "Data Source=PRACHI\\PRACHMSSQLSERVER;Initial Catalog=SRregister;Integrated Security=True";
    public static string _conn {
        get { return con;}
    }

}