﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
/// <summary>
/// Summary description for clsAddRecord
/// </summary>
public class clsAddRecord
{
    #region prop
    public string _rollNO { get; set; }
    public string _name { get; set; }
    public string _fatherName { get; set; }
    public string _contactNO { get; set; }
    public string _whatsappNO { get; set; }
    public string _adress { get; set; }
    public string _gender { get; set; }
    public string _category { get; set; }
    public string _email { get; set; }
    public string _adharID { get; set; }
    public string _PANid { get; set; }
    public string _DOB { get; set; }
    public string _ABCid { get; set; }
    public string _UGcourse { get; set; }
    public string _PGcourse { get; set; }
    public string _admission { get; set; }
    public string _10Year { get; set; }
    public string _10Per { get; set; }
    public string _10RollNO { get; set; }
    public string _10Board { get; set; }
    public string _10schoolName { get; set; }
    public string _12Year { get; set; }
    public string _12Per { get; set; }
    public string _12RollNO { get; set; }
    public string _12Board { get; set; }
    public string _12schoolName { get; set; }
    public string _graduation { get; set; }
    public string _university { get; set; }
    public string _sd { get; set; }
    public string _Nonsd { get; set; }
    public long _userid { get; set; }
    public long _id { get; set; }
    public string _1SemMarks { get; set; }
    public string _Out1SemMarks { get; set; }
    public string _2SemMarks { get; set; }
    public string _Out2SemMarks { get; set; }
    public string _3SemMarks { get; set; }
    public string _Out3SemMarks { get; set; }
    public string _4SemMarks { get; set; }
    public string _Out4SemMarks { get; set; }
    public string _PGstatus { get; set; }
    public long _stuid { get; set; }
    public long _mid { get; set; }
    #endregion

    public int add()
    {
        SqlParameter[] sqpara = new SqlParameter[32];
        sqpara[0] = new SqlParameter("@rollNO", SqlDbType.VarChar);
        sqpara[0].Value=_rollNO;
        sqpara[1] = new SqlParameter("@name", SqlDbType.VarChar);
        sqpara[1].Value = _name;
        sqpara[2] = new SqlParameter("@fatherName", SqlDbType.VarChar);
        sqpara[2].Value = _fatherName;
        sqpara[3] = new SqlParameter("@contactNO", SqlDbType.VarChar);
        sqpara[3].Value = _contactNO;
        sqpara[4] = new SqlParameter("@adress", SqlDbType.VarChar);
        sqpara[4].Value = _adress;
        sqpara[5] = new SqlParameter("@gender", SqlDbType.VarChar);
        sqpara[5].Value = _gender;
        sqpara[6] = new SqlParameter("@category", SqlDbType.VarChar);
        sqpara[6].Value = _category;
        sqpara[7] = new SqlParameter("@email", SqlDbType.VarChar);
        sqpara[7].Value = _email;
        sqpara[8] = new SqlParameter("@adharID", SqlDbType.VarChar);
        sqpara[8].Value = _adharID;
        sqpara[9] = new SqlParameter("@dob", SqlDbType.VarChar);
        sqpara[9].Value = _DOB;
        sqpara[10] = new SqlParameter("@addmission", SqlDbType.VarChar);
        sqpara[10].Value = _admission;
        sqpara[11] = new SqlParameter("@10year ", SqlDbType.VarChar);
        sqpara[11].Value = _10Year;
        sqpara[12] = new SqlParameter("@10per", SqlDbType.VarChar);
        sqpara[12].Value =_10Per;
        sqpara[13] = new SqlParameter("@10RollNO ", SqlDbType.VarChar);
        sqpara[13].Value = _10RollNO;
        sqpara[14] = new SqlParameter("@board", SqlDbType.VarChar);
        sqpara[14].Value = _10Board;
        sqpara[15] = new SqlParameter("@schoolName", SqlDbType.VarChar);
        sqpara[15].Value = _10schoolName;
        sqpara[16] = new SqlParameter("@12year", SqlDbType.VarChar);
        sqpara[16].Value = _12Year;
        sqpara[17] = new SqlParameter("@12per", SqlDbType.VarChar);
        sqpara[17].Value = _12Per;
        sqpara[18] = new SqlParameter("@12RollNO", SqlDbType.VarChar);
        sqpara[18].Value = _12RollNO;
        sqpara[19] = new SqlParameter("@12board", SqlDbType.VarChar);
        sqpara[19].Value = _12Board;
        sqpara[20] = new SqlParameter("@12SchoolName", SqlDbType.VarChar);
        sqpara[20].Value = _12schoolName;

        sqpara[21] = new SqlParameter("@graduation", SqlDbType.VarChar);
        sqpara[21].Value = _graduation;
        sqpara[22] = new SqlParameter("@university", SqlDbType.VarChar);
        sqpara[22].Value = _university;

        sqpara[23] = new SqlParameter("@sd", SqlDbType.VarChar);
        sqpara[23].Value = _sd;
        sqpara[24] = new SqlParameter("@otherNonSD", SqlDbType.VarChar);
        sqpara[24].Value = _Nonsd;

        
        sqpara[25] = new SqlParameter("@cmd", SqlDbType.VarChar);
        sqpara[25].Value = "add";
        sqpara[26] = new SqlParameter("@whatsppNO", SqlDbType.VarChar);
        sqpara[26].Value = _whatsappNO;
        sqpara[27] = new SqlParameter("@PANno", SqlDbType.VarChar);
        sqpara[27].Value = _PANid;
        sqpara[28] = new SqlParameter("@ABCID", SqlDbType.VarChar);
        sqpara[28].Value = _ABCid;
        sqpara[29] = new SqlParameter("@UGcourse", SqlDbType.VarChar);
        sqpara[29].Value = _UGcourse;
        sqpara[30] = new SqlParameter("@PGcourse", SqlDbType.VarChar);
        sqpara[30].Value = _PGcourse;
        sqpara[31] = new SqlParameter("@userid", SqlDbType.BigInt);
        sqpara[31].Value = _userid;
        int res = SqlHelper.ExecuteNonQuery(clscon._conn, CommandType.StoredProcedure, "AddRecordSP", sqpara);
        return res;

    }
    public int updateRecord()
    {
        SqlParameter[] sqpara = new SqlParameter[27];
        sqpara[0] = new SqlParameter("@rollNO", SqlDbType.VarChar);
        sqpara[0].Value = _rollNO;
        sqpara[1] = new SqlParameter("@name", SqlDbType.VarChar);
        sqpara[1].Value = _name;
        sqpara[2] = new SqlParameter("@fatherName", SqlDbType.VarChar);
        sqpara[2].Value = _fatherName;
        sqpara[3] = new SqlParameter("@contactNO", SqlDbType.VarChar);
        sqpara[3].Value = _contactNO;
        sqpara[4] = new SqlParameter("@adress", SqlDbType.VarChar);
        sqpara[4].Value = _adress;
        sqpara[5] = new SqlParameter("@gender", SqlDbType.VarChar);
        sqpara[5].Value = _gender;
        sqpara[6] = new SqlParameter("@category", SqlDbType.VarChar);
        sqpara[6].Value = _category;
        sqpara[7] = new SqlParameter("@email", SqlDbType.VarChar);
        sqpara[7].Value = _email;
        sqpara[8] = new SqlParameter("@adharID", SqlDbType.VarChar);
        sqpara[8].Value = _adharID;
        sqpara[9] = new SqlParameter("@dob", SqlDbType.VarChar);
        sqpara[9].Value = _DOB;
        sqpara[10] = new SqlParameter("@addmission", SqlDbType.VarChar);
        sqpara[10].Value = _admission;
        sqpara[11] = new SqlParameter("@10year ", SqlDbType.VarChar);
        sqpara[11].Value = _10Year;
        sqpara[12] = new SqlParameter("@10per", SqlDbType.VarChar);
        sqpara[12].Value = _10Per;
        sqpara[13] = new SqlParameter("@10RollNO ", SqlDbType.VarChar);
        sqpara[13].Value = _10RollNO;
        sqpara[14] = new SqlParameter("@board", SqlDbType.VarChar);
        sqpara[14].Value = _10Board;
        sqpara[15] = new SqlParameter("@schoolName", SqlDbType.VarChar);
        sqpara[15].Value = _10schoolName;
        sqpara[16] = new SqlParameter("@12year", SqlDbType.VarChar);
        sqpara[16].Value = _12Year;
        sqpara[17] = new SqlParameter("@12per", SqlDbType.VarChar);
        sqpara[17].Value = _12Per;
        sqpara[18] = new SqlParameter("@12RollNO", SqlDbType.VarChar);
        sqpara[18].Value = _12RollNO;
        sqpara[19] = new SqlParameter("@12board", SqlDbType.VarChar);
        sqpara[19].Value = _12Board;
        sqpara[20] = new SqlParameter("@12SchoolName", SqlDbType.VarChar);
        sqpara[20].Value = _12schoolName;

        sqpara[21] = new SqlParameter("@graduation", SqlDbType.VarChar);
        sqpara[21].Value = _graduation;
        sqpara[22] = new SqlParameter("@university", SqlDbType.VarChar);
        sqpara[22].Value = _university;

        sqpara[23] = new SqlParameter("@sd", SqlDbType.VarChar);
        sqpara[23].Value = _sd;
        sqpara[24] = new SqlParameter("@otherNonSD", SqlDbType.VarChar);
        sqpara[24].Value = _Nonsd;

        sqpara[25] = new SqlParameter("@id", SqlDbType.BigInt);
        sqpara[25].Value = _id;

        sqpara[26] = new SqlParameter("@cmd", SqlDbType.VarChar);
        sqpara[26].Value = "edit";

        int resEDIT = SqlHelper.ExecuteNonQuery(clscon._conn, CommandType.StoredProcedure, "AddRecordSP", sqpara);
        return resEDIT;
    }

    //public int addMarks()
    //{
    //    SqlParameter[] sqlpa = new SqlParameter[12];
    //    sqlpa[0] = new SqlParameter("@1stSem", SqlDbType.VarChar);
    //    sqlpa[0].Value = _1SemMarks;
    //    sqlpa[1] = new SqlParameter("@2Sem", SqlDbType.VarChar);
    //    sqlpa[1].Value = _2SemMarks;
    //    sqlpa[2] = new SqlParameter("@3Sem", SqlDbType.VarChar);
    //    sqlpa[2].Value = _3SemMarks;
    //    sqlpa[3] = new SqlParameter("@4Sem", SqlDbType.VarChar);
    //    sqlpa[3].Value = _4SemMarks;
    //    sqlpa[4] = new SqlParameter("@out1stSem", SqlDbType.VarChar);
    //    sqlpa[4].Value = _Out1SemMarks;
    //    sqlpa[5] = new SqlParameter("@out2ndSem", SqlDbType.VarChar);
    //    sqlpa[5].Value = _Out2SemMarks;
    //    sqlpa[6] = new SqlParameter("@out3rdSem", SqlDbType.VarChar);
    //    sqlpa[6].Value = _Out4SemMarks;
    //    sqlpa[7] = new SqlParameter("@out4thSem", SqlDbType.VarChar);
    //    sqlpa[7].Value = _Out4SemMarks;
    //    sqlpa[8] = new SqlParameter("@status ", SqlDbType.VarChar);
    //    sqlpa[8].Value = _PGstatus;
    //    sqlpa[9] = new SqlParameter("@rollNO ", SqlDbType.VarChar);
    //    sqlpa[9].Value = _rollNO;
    //    sqlpa[10] = new SqlParameter("@stuid ", SqlDbType.BigInt);
    //    sqlpa[10].Value = _stuid;

    //    sqlpa[11] = new SqlParameter("@cmd", SqlDbType.VarChar);
    //    sqlpa[11].Value = "Addmarks";

    //    int ress = SqlHelper.ExecuteNonQuery(clscon._conn, CommandType.StoredProcedure, "AddRecordSP", sqlpa);
    //    return ress;
    //}

    //public int UpdateMarks()
    //{
    //    SqlParameter[] sqlpa = new SqlParameter[12];
    //    sqlpa[0] = new SqlParameter("@1stSem", SqlDbType.VarChar);
    //    sqlpa[0].Value = _1SemMarks;
    //    sqlpa[1] = new SqlParameter("@2Sem", SqlDbType.VarChar);
    //    sqlpa[1].Value = _2SemMarks;
    //    sqlpa[2] = new SqlParameter("@3Sem", SqlDbType.VarChar);
    //    sqlpa[2].Value = _3SemMarks;
    //    sqlpa[3] = new SqlParameter("@4Sem", SqlDbType.VarChar);
    //    sqlpa[3].Value = _4SemMarks;
    //    sqlpa[4] = new SqlParameter("@out1stSem", SqlDbType.VarChar);
    //    sqlpa[4].Value = _Out1SemMarks;
    //    sqlpa[5] = new SqlParameter("@out2ndSem", SqlDbType.VarChar);
    //    sqlpa[5].Value = _Out2SemMarks;
    //    sqlpa[6] = new SqlParameter("@out3rdSem", SqlDbType.VarChar);
    //    sqlpa[6].Value = _Out4SemMarks;
    //    sqlpa[7] = new SqlParameter("@out4thSem", SqlDbType.VarChar);
    //    sqlpa[7].Value = _Out4SemMarks;
    //    sqlpa[8] = new SqlParameter("@status ", SqlDbType.VarChar);
    //    sqlpa[8].Value = _PGstatus;
    //    sqlpa[9] = new SqlParameter("@mid ", SqlDbType.BigInt);
    //    sqlpa[9].Value = _mid;

    //    sqlpa[10] = new SqlParameter("@cmd", SqlDbType.VarChar);
    //    sqlpa[10].Value = "UpdateMarks";

    //    int ress = SqlHelper.ExecuteNonQuery(clscon._conn, CommandType.StoredProcedure, "AddRecordSP", sqlpa);
    //    return ress;
    //}
}