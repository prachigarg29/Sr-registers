﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
/// <summary>
/// Summary description for registerLogin
/// </summary>
public class registerLogin
{
    #region prop
    public string _fname { get; set; }
    public string _femail { get; set; }
    public string _fdepat { get; set; }
    public string _fpswd { get; set; }
    #endregion
    
    public int registercode()
    {
        
        SqlParameter[] sqpara = new SqlParameter[5];
        sqpara[0] = new SqlParameter("@fname", SqlDbType.VarChar);
        sqpara[0].Value = _fname;

        sqpara[1] = new SqlParameter("@femail", SqlDbType.NVarChar);
        sqpara[1].Value = _femail;

        sqpara[2] = new SqlParameter("@fdepat", SqlDbType.VarChar);
        sqpara[2].Value = _fdepat;

        sqpara[3] = new SqlParameter("@fpswd", SqlDbType.NVarChar);
        sqpara[3].Value = _fpswd;

        sqpara[4] = new SqlParameter("@cmd", SqlDbType.NVarChar);
        sqpara[4].Value = "register";

        int res = SqlHelper.ExecuteNonQuery(clscon._conn, CommandType.StoredProcedure, "Managefacultydata", sqpara);
        return res;

    }
    public DataSet Stulogin()
    {
      
        SqlParameter[] sqlpara = new SqlParameter[3];
        sqlpara[0] = new SqlParameter("@femail", SqlDbType.NVarChar);
        sqlpara[0].Value = _femail;
        sqlpara[1] = new SqlParameter("@fpswd", SqlDbType.NVarChar);
        sqlpara[1].Value = _fpswd;
        sqlpara[2] = new SqlParameter("@cmd", SqlDbType.VarChar);
        sqlpara[2].Value = "login";
        DataSet ds = SqlHelper.ExecuteDataset(clscon._conn, CommandType.StoredProcedure, "Managefacultydata", sqlpara);
        return ds;
    }

}