﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
public partial class editDetails : System.Web.UI.Page
{
    long id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.QueryString.HasKeys())
        {
            id = Convert.ToInt64(Request.QueryString["id"].ToString());
        }

        if (!IsPostBack)
        {
           
            SqlConnection sqlcon = new SqlConnection(clscon._conn);
            string cmd = @"select * from  [SRregister].[dbo].[srRecords] where STudentID=" + id;
            SqlDataAdapter sqlad = new SqlDataAdapter(cmd, sqlcon);

            DataSet ds = new DataSet();
            sqlad.Fill(ds);

            if (ds.Tables[0].Rows.Count > 0)
            {
                txtRollNo.Text = ds.Tables[0].Rows[0]["RollNo"].ToString();
                txtname.Text = ds.Tables[0].Rows[0]["NameOfStudent"].ToString();
                Session.Add("stuname", ds.Tables[0].Rows[0]["NameOfStudent"].ToString());
                txtFatherName.Text = ds.Tables[0].Rows[0]["FatherName"].ToString();
                txtMobileNo.Text = ds.Tables[0].Rows[0]["ContactNo"].ToString();
                txtAddress.Text = ds.Tables[0].Rows[0]["StudAddress"].ToString();
                txtgender.Text = ds.Tables[0].Rows[0]["Gender"].ToString();
                txtCategory.Text = ds.Tables[0].Rows[0]["Category"].ToString();
                txtEmail.Text = ds.Tables[0].Rows[0]["EmailiD"].ToString();
                txtAdharNO.Text = ds.Tables[0].Rows[0]["AdharCardNO"].ToString();
                txtDOB.Text = ds.Tables[0].Rows[0]["DOB"].ToString();
                txtDateAdd.Text = ds.Tables[0].Rows[0]["AddmissonDate"].ToString();
                txt10thYear.Text = ds.Tables[0].Rows[0]["PassYearOf10"].ToString();
                txt10thPercentage.Text = ds.Tables[0].Rows[0]["PercentageOf10"].ToString();
                txt10thRoll.Text = ds.Tables[0].Rows[0]["RollNoOf10"].ToString();
                txt10thBoard.Text = ds.Tables[0].Rows[0]["Board"].ToString();
                txt10schoolName.Text = ds.Tables[0].Rows[0]["SchoolName"].ToString();
                txt12thYear.Text = ds.Tables[0].Rows[0]["PassingYearOf12"].ToString();
                txt12thPercentage.Text = ds.Tables[0].Rows[0]["PercentageOf12"].ToString();
                txt12thRoll.Text = ds.Tables[0].Rows[0]["RollNoOf12"].ToString();
                txt12thBoard.Text = ds.Tables[0].Rows[0]["BoardOf12"].ToString();
                txt12thschoolName.Text = ds.Tables[0].Rows[0]["schoolNameOf12"].ToString();
                txtGraduationYear.Text = ds.Tables[0].Rows[0]["GraduationYear"].ToString();
                txtUniversity.Text = ds.Tables[0].Rows[0]["University"].ToString();
                txtSD.Text = ds.Tables[0].Rows[0]["SD"].ToString();
                txtNonSD.Text = ds.Tables[0].Rows[0]["OtherNonSD"].ToString();
            }
        }
    }

    protected void btnUpdateDATA_Click(object sender, EventArgs e)
    {
        #region
        //clsAddRecord objcls = new clsAddRecord();
        //objcls._rollNO = txtRollNo.Text;
        //objcls._name = txtname.Text;
        //objcls._fatherName = txtFatherName.Text;
        //objcls._contactNO = txtMobileNo.Text;
        //objcls._adress = txtAddress.Text;
        //objcls._gender = txtgender.Value;
        //objcls._category = txtCategory.Text;
        //objcls._email = txtEmail.Text;
        //objcls._adharID = txtAdharNO.Text;
        //objcls._DOB = txtDOB.Text;
        //objcls._admission = txtDateAdd.Text;
        //objcls._10Year = txt10thYear.Text;
        //objcls._10Per = txt10thPercentage.Text;
        //objcls._10RollNO = txt10thRoll.Text;
        //objcls._10Board = txt10thBoard.Text;
        //objcls._10schoolName = txt10schoolName.Text;
        //objcls._12Year = txt12thYear.Text;
        //objcls._12Per = txt12thPercentage.Text;
        //objcls._12RollNO = txt12thRoll.Text;
        //objcls._12Board = txt12thBoard.Text;
        //objcls._12schoolName = txt12thschoolName.Text;
        //objcls._graduation = txtGraduationYear.Text;
        //objcls._university = txtUniversity.Text;
        //objcls._sd = txtSD.Text;
        //objcls._Nonsd = txtNonSD.Text;
        //objcls._id = id;
        //int res = objcls.updateRecord();
        //if (res > 0)
        //{
        //    Response.Redirect("ShowRecord.aspx");
        //}
        //Response.Redirect("ShowRecord.aspx");
        #endregion

        SqlConnection con = new SqlConnection(clscon._conn);
        string cmd = @"update [dbo].[srRecords] set [RollNo]='"+txtRollNo.Text.Trim()+"',[NameOfStudent]='"+txtname.Text.Trim()+"',[FatherName]='"+txtFatherName.Text.Trim()+"',[ContactNo]='"+txtMobileNo.Text.Trim()+"',[StudAddress]='"+txtAddress.Text.Trim()+"',[Gender]='"+txtgender.Text.Trim()+"',[Category]='"+txtCategory.Text.Trim()+ "',[EmailiD]='" + txtEmail.Text.Trim() + "',[AdharCardNO]='" + txtAdharNO.Text.Trim() + "',[DOB]='" + txtDOB.Text.Trim() + "',[AddmissonDate]='" + txtDateAdd.Text.Trim() + "',[PassYearOf10]='" + txt10thYear.Text.Trim() + "',[PercentageOf10]='" + txt10thPercentage.Text.Trim() + "',[RollNoOf10]='" + txt10thRoll.Text.Trim() + "',[Board]='" + txt10thBoard.Text.Trim() + "',[SchoolName]='" + txt10schoolName.Text.Trim() + "',[PassingYearOf12]='" + txt12thYear.Text.Trim() + "',[PercentageOf12]='" + txt12thPercentage.Text.Trim() + "',[RollNoOf12]='" + txt12thRoll.Text.Trim() + "',[BoardOf12]='" + txt12thBoard.Text.Trim() + "',[schoolNameOf12]='" + txt12thschoolName.Text.Trim() + "',[GraduationYear]='" + txtGraduationYear.Text.Trim() + "',[University]='" + txtUniversity.Text.Trim() + "',[SD]='" + txtSD.Text.Trim() + "',[OtherNonSD]='" + txtNonSD.Text.Trim() + "'where STudentID=" + id;
        SqlCommand sqlcmd = new SqlCommand(cmd,con);
        con.Open();
        if(sqlcmd.ExecuteNonQuery()>0)
        {
            Response.Redirect("ShowRecord.aspx");
        }
    }
}