﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

public partial class Register : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnregister_Click(object sender, EventArgs e)
    {
        //SqlConnection sqlcon = new SqlConnection(clscon._conn);
        //string checkEmail = @"select facultyEmail from [SRrecord].[dbo].[faculty_details] where facultyEmail=@Email";
        //SqlCommand sqlcmd = new SqlCommand(checkEmail, sqlcon);
        //sqlcmd.Parameters.AddWithValue("@Email", txtfemail.Text.Trim());
        //sqlcon.Open();
        //object result = sqlcmd.ExecuteScalar();

        //if (result != null)
        //{
        //    Response.Write("<script>alert('Email is already exist...')</script>");
        //}
        //else
        //{
        //    SqlConnection sqlconn = new SqlConnection(clscon._conn);
        //    string cmd = @"insert into [SRrecord].[dbo].[faculty_details]  (facultyName,facultyEmail,fDepart,Fpswd) values ('" + txtfname.Text.Trim() + "','" + txtfemail.Text.Trim() + "','" + txtfdepartment.Text.Trim() + "','" + txtpswd.Text.Trim() + "');";
        //    SqlCommand sqlcmdd = new SqlCommand(cmd, sqlcon);
        //    sqlconn.Open();
        //    int res = sqlcmdd.ExecuteNonQuery();
        //    if (res > 0)
        //    {

        //        txtfname.Text = string.Empty;
        //        txtfemail.Text = string.Empty;
        //        txtfdepartment.Text = string.Empty;
        //        txtpswd.Text = string.Empty;
        //        txtConfrmpswd.Text = string.Empty;
        //        Response.Redirect("Login.aspx");
        //    }
        //}

    }

    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        registerLogin objcls = new registerLogin();
        objcls._fname = txtfname.Text.Trim();
        objcls._femail = txtfemail.Text.Trim();
        objcls._fdepat = txtfdepartment.Text.Trim();
        objcls._fpswd = txtpswd.Text.Trim();
        int res = objcls.registercode();
        if (res > 0)
        {

            txtfname.Text = string.Empty;
            txtfemail.Text = string.Empty;
            txtfdepartment.Text = string.Empty;
            txtpswd.Text = string.Empty;
            txtConfrmpswd.Text = string.Empty;
            Response.Redirect("Login.aspx");
        }
        Response.Redirect("Login.aspx");

    }
}