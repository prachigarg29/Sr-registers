﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Configuration;
using Microsoft.Office.Interop.Excel;
using System.Data.OleDb;
using System.Data.Common;
using System.Globalization;
using System.Diagnostics;
using System.Web.Services;
using System.Data;
public partial class _Default : System.Web.UI.Page
{

    long sid = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
       fecthid();

    }
    public void fecthid()
    {

        SqlConnection sqlcon = new SqlConnection(clscon._conn);
        string cmd = @"select * FROM  [SRregister].[dbo].[srRecords] ";
        SqlDataAdapter sqlad = new SqlDataAdapter(cmd, sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            sid = Convert.ToInt64(ds.Tables[0].Rows[0]["STudentID"].ToString());
            Session.Add("Sid", sid);
            GridView1.DataSource = ds;
            GridView1.DataBind();
           
        }
      
    }

    protected void btnsubmit_Click1(object sender, ImageClickEventArgs e)
    {
        SqlConnection sqlcon = new SqlConnection(clscon._conn);
        string cmd = @"select * FROM  [SRregister].[dbo].[srRecords]  WHERE [RollNo] LIKE '%' + '" + txtsearchBarData.Text.Trim() + "' +'%' ";
        SqlDataAdapter sqlad = new SqlDataAdapter(cmd, sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {

            GridView1.DataSource = ds;
            GridView1.DataBind();
            txtsearchBarData.Text = string.Empty;
        }
    }

    [WebMethod]
    public static List<string> getcompleteList(string RollNo)
    {
        List<string> getitem = new List<string>();
        SqlConnection sqlcon = new SqlConnection(clscon._conn);
        DataSet ds = new DataSet();
        System.Data.DataTable dt = new System.Data.DataTable();
        using (SqlCommand cmd = new SqlCommand())
        {
            cmd.CommandText = @"select [RollNo] from [SRregister].[dbo].[srRecords] where [RollNo] like @Text";
            cmd.Parameters.AddWithValue("@Text", "%" + RollNo + "%");
            cmd.Connection = sqlcon;
            sqlcon.Open();

            SqlDataAdapter ad = new SqlDataAdapter(cmd);
            ad.Fill(ds);
        }
        sqlcon.Close();

        dt = ds.Tables[0];
        List<string> txtItems = new List<string>();
        String dbValues;

        foreach (DataRow row in dt.Rows)
        {
            //String From DataBase(dbValues)
            dbValues = row["RollNo"].ToString();
            //dbValues = dbValues.ToLower();
            txtItems.Add(dbValues);
        }

        return txtItems;
        //return getitem;
    }

    protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Attributes.Add("onMouseOver", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='#DEEFF5';this.style.cursor='pointer';");
            e.Row.Attributes.Add("OnMouseOut", "this.style.backgroundColor=this.originalstyle;");
        }
    }
    public void fetchMarksData()
    {

    }

    protected string GetMarksLink(string studentId)
    {

        long studentID = Convert.ToInt64(studentId); // Use studentId from parameters
        string link;

        using (SqlConnection con = new SqlConnection(clscon._conn))
        {
            // Adjust the query to filter by studentID
            string cmdText = @"SELECT r.[STudentID],
                               m.[Marks_1st_sem],
                               m.[Marks_2nd_sem],
                               m.[Marks_3rd_sem],
                               m.[Marks_4th_sem]
                        FROM [SRregister].[dbo].[srRecords] r
                        FULL JOIN [SRregister].[dbo].[tbl_marks] m
                        ON m.[stuId] = r.[STudentID] where r.[STudentID] = "+studentID;
             using (SqlCommand cmd = new SqlCommand(cmdText, con))
            {
                cmd.Parameters.AddWithValue("@StudentID", studentID);
                SqlDataAdapter sqlcmd = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                sqlcmd.Fill(ds);

                // Check if the DataSet has rows
                if (ds.Tables[0].Rows.Count > 0)
                {



                    if (!string.IsNullOrEmpty(ds.Tables[0].Rows[0]["Marks_1st_sem"].ToString()) && !string.IsNullOrEmpty(ds.Tables[0].Rows[0]["Marks_2nd_sem"].ToString()) && !string.IsNullOrEmpty(ds.Tables[0].Rows[0]["Marks_3rd_sem"].ToString() ) && !string.IsNullOrEmpty(ds.Tables[0].Rows[0]["Marks_4th_sem"].ToString()))
                    {
                        // Marks are present; return Update Marks link
                        link = "<a href='AddMarks.aspx?v=AM&id=" + studentID + "' style='color:#f70d1a'>Update Marked</a>";

                    }


                    else
                    {
                        // Some marks are missing; return Add Marks link
                        link = "<a href='AddMarks.aspx?v=AM&id=" + studentID + "' style='color:#9090EE'>Add Marks</a>";
                    }
                }
                else
                {
                    // No records found; return Add Marks link
                    link = "<a href='AddMarks.aspx?v=AM&id=" + studentID + "' style='color:#3187A2'>Add Marks</a>";
                }
            }
        }

        return link;
    }

    protected void GridView1_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        GridView1.PageIndex = e.NewPageIndex;
        this.fecthid();
    }

    protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (Convert.ToInt32(DropDownList1.SelectedItem.Value) != 0)
        {
            int pageSize = Convert.ToInt32(DropDownList1.SelectedValue);
            GridView1.PageSize = pageSize;
            // Rebind the GridView to reflect the new page size
            fecthid();
        }
        else
        {
            ClientScript.RegisterStartupScript(this.GetType(), "alert", "alert('Please select number of rows to be display..');", true);
            
        }
    }
}