﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

public partial class Userprofile : System.Web.UI.Page
{
    long id = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        pnlprofile.Visible = true;
        editpro.Visible = false;
        pnlchngpswd.Visible = false;
        id = Convert.ToInt64(Session["Fid"]);
        bindadta();
        // getdata();
    }
    public void getdata()
    {
        //if (!IsPostBack)
        {

            SqlConnection sqlcon = new SqlConnection(clscon._conn);
            string strcmd = @"select [facultyid],[facultyName],[facultyEmail],[fDepart],[Fpswd] FROM [SRregister].[dbo].[faculty_details] where facultyid=" + id;
            SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
            DataSet ds = new DataSet();
            sqlad.Fill(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                dtlist.DataSource = ds;
                dtlist.DataBind();
                txtname.Text = ds.Tables[0].Rows[0]["facultyName"].ToString();
                txtemail.Text = ds.Tables[0].Rows[0]["facultyEmail"].ToString();
                txtdept.Text = ds.Tables[0].Rows[0]["fDepart"].ToString();
            }
        }
    }
    public void bindadta()
    {

        SqlConnection sqlcon = new SqlConnection(clscon._conn);
        string strcmd = @"select [facultyid],[facultyName],[facultyEmail],[fDepart],[Fpswd] FROM [SRregister].[dbo].[faculty_details] where facultyid=" + id;
        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if (ds.Tables[0].Rows.Count > 0)
        {
            dtlist.DataSource = ds;
            dtlist.DataBind();

        }
    }
    protected void editprofile_Click(object sender, EventArgs e)
    {
        editpro.Visible = true;
        pnlprofile.Visible = false;
        pnlchngpswd.Visible = false;
        getdata();

    }

    protected void btnsave_Click(object sender, EventArgs e)
    {
        SqlConnection sqlcon = new SqlConnection(clscon._conn);
        string strcmd = @"update [SRregister].[dbo].[faculty_details] set facultyName='" + txtname.Text.Trim() + "',fDepart='" + txtdept.Text.Trim() + "',facultyEmail='" + txtemail.Text.Trim() + "' where facultyid=" + id;
        SqlCommand sqlcmd = new SqlCommand(strcmd, sqlcon);
        sqlcon.Open();
        if (sqlcmd.ExecuteNonQuery() > 0)
        {
            Response.Redirect("Userprofile.aspx");
        }
    }

    protected void chngpswd_Click(object sender, EventArgs e)
    {
        pnlchngpswd.Visible = true;
        pnlprofile.Visible = false;
        editpro.Visible = false;
    }

    protected void btnchnge_Click(object sender, EventArgs e)
    {
        SqlConnection sqlcon = new SqlConnection(clscon._conn);
        string strcmd = @"select [facultyid],[facultyName],[facultyEmail],[fDepart],[Fpswd] FROM [SRregister].[dbo].[faculty_details] where facultyid=" + id;
        SqlDataAdapter sqlad = new SqlDataAdapter(strcmd, sqlcon);
        DataSet ds = new DataSet();
        sqlad.Fill(ds);
        if(ds.Tables[0].Rows[0]["Fpswd"].ToString()==txtold.Text)
        {
            string strup = @"update [SRregister].[dbo].[faculty_details] set [Fpswd]='" + txtnew.Text.Trim() + "' where facultyid=" + id;
            SqlCommand sqlcmd = new SqlCommand(strup, sqlcon);
            sqlcon.Open();
            if (sqlcmd.ExecuteNonQuery() > 0)
            {
                Response.Write("<script>alert('updated success...')</script>");
                Response.Redirect("Userprofile.aspx");
            }
        }
    }
}